package com.iembuttons

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.accessibilityservice.GestureDescription.StrokeDescription
import android.graphics.Path
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class ButtonService : AccessibilityService() {
    private val h = Handler(Looper.getMainLooper())
    private val sp by lazy { getSharedPreferences("cfg", MODE_PRIVATE) }
    private var count = 0
    private var cur: String? = null
    private var passDown = true
    private var stroke: StrokeDescription? = null
    private var hx = 0f
    private var hy = 0f
    private var holdAt = 0L

    private val resolveRun = Runnable { if (count > 0) { count = 0; act(1) } }

    private val YT_SHORTS = listOf(
        "com.google.android.youtube:id/reel_recycler",
        "com.google.android.youtube:id/reel_player_page_container")
    private val IG_REELS = listOf(
        "com.instagram.android:id/clips_viewer_view_pager",
        "com.instagram.android:id/clips_video_container",
        "com.instagram.android:id/clips_viewer_container")
    private val IG_STORIES = listOf(
        "com.instagram.android:id/reel_viewer_root",
        "com.instagram.android:id/reel_viewer_media_layout",
        "com.instagram.android:id/reel_viewer_progress_bar")

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (stroke != null && e?.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            SystemClock.uptimeMillis() - holdAt > 700) releaseHold()
    }
    override fun onInterrupt() {}

    private fun on(k: String) = sp.getBoolean(k, true)

    private fun has(root: AccessibilityNodeInfo, ids: List<String>): Boolean = try {
        ids.any { root.findAccessibilityNodeInfosByViewId(it).isNotEmpty() }
    } catch (e: Exception) { false }

    // null = do nothing, let phone handle the button normally
    private fun decide(): String? {
        if (!on("master")) return null
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        if (am.mode != AudioManager.MODE_NORMAL) return null   // calls ringing / in call
        val root = rootInActiveWindow ?: return null
        return when (root.packageName?.toString()) {
            "com.google.android.youtube" ->
                if (!on("app_yt")) null else if (has(root, YT_SHORTS)) "reel" else "long"
            "com.instagram.android" ->
                if (!on("app_ig")) null
                else if (on("ig_story") && !has(root, IG_REELS) && has(root, IG_STORIES)) "story"
                else "reel"
            "com.reddit.frontpage" -> if (on("app_rd")) "reddit" else null
            else -> null
        }
    }

    override fun onKeyEvent(e: KeyEvent): Boolean {
        val c = e.keyCode
        if (c != KeyEvent.KEYCODE_HEADSETHOOK && c != KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE &&
            c != KeyEvent.KEYCODE_MEDIA_NEXT && c != KeyEvent.KEYCODE_MEDIA_PREVIOUS) return false
        if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0) {
            cur = decide()
            passDown = cur == null
        }
        if (passDown) return false
        if (e.action != KeyEvent.ACTION_UP) return true
        when (c) {
            KeyEvent.KEYCODE_MEDIA_NEXT -> { h.removeCallbacks(resolveRun); count = 0; act(2) }
            KeyEvent.KEYCODE_MEDIA_PREVIOUS -> {}
            else -> {
                h.removeCallbacks(resolveRun)
                if (e.eventTime - e.downTime > 600) { count = 0; return true } // long press: ignore
                count++
                if (count >= 2) { count = 0; act(2) } else h.postDelayed(resolveRun, 260)
            }
        }
        return true
    }

    private fun act(n: Int) {
        val g = cur ?: return
        val w = resources.displayMetrics.widthPixels.toFloat()
        val hh = resources.displayMetrics.heightPixels.toFloat()
        when (g) {
            "long" -> media(if (n == 1) KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE else KeyEvent.KEYCODE_MEDIA_NEXT)
            "reel" -> if (n == 1) tap(w / 2, hh / 2, 50) else swipeUp(w, hh)
            "reddit" -> if (n == 1) redditToggle(w, hh) else swipeUp(w, hh)
            "story" -> if (n == 1) {
                if (stroke != null) releaseHold() else startHold(w / 2, hh / 2)
            } else {
                val held = stroke != null
                releaseHold()
                if (held) h.postDelayed({ tap(w * 0.9f, hh / 2, 50) }, 150) else tap(w * 0.9f, hh / 2, 50)
            }
        }
    }

    private fun media(code: Int) {
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun go(s: StrokeDescription) {
        dispatchGesture(GestureDescription.Builder().addStroke(s).build(), null, null)
    }

    private fun tap(x: Float, y: Float, d: Long) {
        go(StrokeDescription(Path().apply { moveTo(x, y) }, 0, d))
    }

    private fun swipeUp(w: Float, hh: Float) {
        go(StrokeDescription(Path().apply { moveTo(w / 2, hh * 0.75f); lineTo(w / 2, hh * 0.25f) }, 0, 250))
    }

    private fun findPlayPause(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val names = setOf("play", "pause", "play video", "pause video")
        for (t in listOf("Pause", "Play")) {
            for (n in root.findAccessibilityNodeInfosByText(t)) {
                val d = n.contentDescription?.toString()?.trim()?.lowercase()
                if (d != null && d in names) {
                    var x: AccessibilityNodeInfo? = n
                    while (x != null && !x.isClickable) x = x.parent
                    if (x != null) return x
                }
            }
        }
        return null
    }

    private fun redditToggle(w: Float, hh: Float) {
        val root = rootInActiveWindow
        val n = if (root != null) try { findPlayPause(root) } catch (e: Exception) { null } else null
        if (n != null && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return
        tap(w / 2, hh * 0.4f, 120)
    }

    // Stories pause = finger held down on screen until next press
    private fun startHold(x: Float, y: Float) {
        hx = x; hy = y + 1f
        holdAt = SystemClock.uptimeMillis()
        val s = StrokeDescription(Path().apply { moveTo(x, y); lineTo(hx, hy) }, 0, 100, true)
        stroke = s
        go(s)
    }

    private fun releaseHold() {
        val s = stroke ?: return
        stroke = null
        go(s.continueStroke(Path().apply { moveTo(hx, hy); lineTo(hx, hy) }, 0, 50, false))
    }
}
