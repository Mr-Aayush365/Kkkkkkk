package com.iembuttons

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

object Cfg {
    val items = listOf(
        "master" to "MASTER SWITCH (everything on/off)",
        "app_yt" to "YouTube (Shorts + long video)",
        "app_ig" to "Instagram (Reels + Stories)",
        "ig_story" to "Instagram Stories mode (turn OFF if Reels act weird)",
        "app_rd" to "Reddit videos"
    )
}

class MainActivity : Activity() {
    private lateinit var status: TextView
    private var asked = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val sp = getSharedPreferences("cfg", MODE_PRIVATE)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 40, 40, 40)
        }
        status = TextView(this).apply { textSize = 17f; setPadding(0, 0, 0, 20) }
        root.addView(status)
        root.addView(Button(this).apply {
            text = "Open Accessibility Settings"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        for ((k, label) in Cfg.items) {
            root.addView(Switch(this).apply {
                text = label
                textSize = 16f
                setPadding(0, 24, 0, 24)
                isChecked = sp.getBoolean(k, true)
                setOnCheckedChangeListener { _, v -> sp.edit().putBoolean(k, v).apply() }
            })
        }
        setContentView(ScrollView(this).apply {
            addView(root, ViewGroup.LayoutParams(-1, -2))
        })
    }

    override fun onResume() {
        super.onResume()
        val on = serviceOn()
        status.text = if (on) "Permission: ON. App is working." else "Permission: OFF. Turn on 'IEM Buttons' in Accessibility."
        if (!on && !asked) {
            asked = true
            AlertDialog.Builder(this)
                .setTitle("Permission needed")
                .setMessage("Turn on 'IEM Buttons' in Accessibility. It only reads your earphone button and does taps/swipes.\n\nIf it says 'Restricted setting': Phone Settings > Apps > IEM Buttons > ⋮ > Allow restricted settings.")
                .setPositiveButton("Open settings") { _, _ ->
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }
                .setNegativeButton("Later", null)
                .show()
        }
    }

    private fun serviceOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains(packageName) && s.contains("ButtonService")
    }
}
