1. Android Studio > Open > select IEMButtons folder. Accept any upgrade prompt, wait for Sync.
2. Phone: Developer options > USB debugging ON. Plug in. Press Run (green triangle).
3. Open IEM Buttons app > Open settings > Accessibility > IEM Buttons > ON.
   If blocked: Settings > Apps > IEM Buttons > 3 dots > Allow restricted settings.
